-- SP DE CARGA DE TABLAS INT
--sp_carga_int_fact_ventas

CREATE PROCEDURE [dbo].[sp_carga_int_fact_ventas]
AS
BEGIN
     DELETE FROM [DW_COMERCIAL].[dbo].[INT_FACT_VENTAS]

     INSERT INTO [DW_COMERCIAL].[dbo].[INT_FACT_VENTAS] (
          COD_PRODUCTO,
		  COD_CATEGORIA,
          COD_CLIENTE,
          COD_PAIS,
          COD_VENDEDOR,
          COD_SUCURSAL,
          FECHA,
          CANTIDAD_VENDIDA,
          MONTO_VENDIDO,
          PRECIO,
          COMISION_COMERCIAL)
     SELECT COD_PRODUCTO,
            COD_CATEGORIA,
            COD_CLIENTE,
            COD_PAIS,
            COD_VENDEDOR,
            COD_SUCURSAL,
            CONVERT(smalldatetime, fecha, 103),
            TRY_CAST(CANTIDAD_VENDIDA AS DECIMAL(18,2)),
            TRY_CAST(REPLACE(MONTO_VENDIDO, '.', '') AS DECIMAL(18,2)),
            TRY_CAST(ROUND(TRY_CAST(REPLACE(PRECIO, ',', '.') AS DECIMAL(18,4)),2,1) AS DECIMAL(18,2)),
            TRY_CAST(
                     REPLACE(
                             REPLACE(
                                     IIF(COMISION_COMERCIAL LIKE '0.%', REPLACE(COMISION_COMERCIAL, '.', ','), COMISION_COMERCIAL),
                                         '.', ''
                                          ),
                               ',', '.'
                               ) AS DECIMAL(18,2))
             FROM [DW_COMERCIAL].[dbo].[STG_FACT_VENTAS];
-- Buscamos en las tablas dim las correspondientes key
UPDATE [DW_COMERCIAL].[dbo].[INT_FACT_VENTAS]
SET PRODUCTO_KEY = CASE WHEN EXISTS(SELECT 1 FROM DIM_PRODUCTO WHERE DIM_PRODUCTO.COD_PRODUCTO = INT_FACT_VENTAS.COD_PRODUCTO) THEN DIM_PRODUCTO.PRODUCTO_KEY ELSE NULL END,
    CATEGORIA_KEY = CASE WHEN EXISTS(SELECT 1 FROM DIM_CATEGORIA WHERE DIM_CATEGORIA.COD_CATEGORIA = INT_FACT_VENTAS.COD_CATEGORIA) THEN DIM_CATEGORIA.CATEGORIA_KEY ELSE NULL END,
    CLIENTE_KEY = CASE WHEN EXISTS(SELECT 1 FROM DIM_CLIENTE WHERE DIM_CLIENTE.COD_CLIENTE = INT_FACT_VENTAS.COD_CLIENTE) THEN DIM_CLIENTE.CLIENTE_KEY ELSE NULL END,
    PAIS_KEY = CASE WHEN EXISTS(SELECT 1 FROM DIM_PAIS WHERE DIM_PAIS.COD_PAIS = INT_FACT_VENTAS.COD_PAIS) THEN DIM_PAIS.PAIS_KEY ELSE NULL END,
    VENDEDOR_KEY = CASE WHEN EXISTS(SELECT 1 FROM DIM_VENDEDOR WHERE DIM_VENDEDOR.COD_VENDEDOR = INT_FACT_VENTAS.COD_VENDEDOR) THEN DIM_VENDEDOR.VENDEDOR_KEY ELSE NULL END,
    SUCURSAL_KEY = CASE WHEN EXISTS(SELECT 1 FROM DIM_SUCURSAL WHERE DIM_SUCURSAL.COD_SUCURSAL = INT_FACT_VENTAS.COD_SUCURSAL) THEN DIM_SUCURSAL.SUCURSAL_KEY ELSE NULL END
    ,TIEMPO_KEY = [INT_FACT_VENTAS].FECHA
FROM [DW_COMERCIAL].[dbo].[INT_FACT_VENTAS]
LEFT JOIN DIM_PRODUCTO ON DIM_PRODUCTO.COD_PRODUCTO = INT_FACT_VENTAS.COD_PRODUCTO
LEFT JOIN DIM_CATEGORIA ON DIM_CATEGORIA.COD_CATEGORIA = INT_FACT_VENTAS.COD_CATEGORIA
LEFT JOIN DIM_CLIENTE ON DIM_CLIENTE.COD_CLIENTE = INT_FACT_VENTAS.COD_CLIENTE
LEFT JOIN DIM_PAIS ON DIM_PAIS.COD_PAIS = INT_FACT_VENTAS.COD_PAIS
LEFT JOIN DIM_VENDEDOR ON DIM_VENDEDOR.COD_VENDEDOR = INT_FACT_VENTAS.COD_VENDEDOR
LEFT JOIN DIM_SUCURSAL ON DIM_SUCURSAL.COD_SUCURSAL = INT_FACT_VENTAS.COD_SUCURSAL

    --Verificamos que no haya ningun null
    UPDATE [DW_COMERCIAL].[dbo].[INT_FACT_VENTAS]
     SET AGREGAR = CASE 
                    WHEN PRODUCTO_KEY IS NOT NULL AND CATEGORIA_KEY IS NOT NULL AND CLIENTE_KEY IS NOT NULL 
                     AND PAIS_KEY IS NOT NULL AND VENDEDOR_KEY IS NOT NULL AND SUCURSAL_KEY IS NOT NULL 
                     AND TIEMPO_KEY IS NOT NULL AND CANTIDAD_VENDIDA IS NOT NULL AND MONTO_VENDIDO IS NOT NULL 
                     AND PRECIO = ROUND(MONTO_VENDIDO/CANTIDAD_VENDIDA, 2,1) 
                   THEN 'SI' 
                  ELSE 'NO' 
                 END
     -- Verificar que no haya registros duplicados
UPDATE [DW_COMERCIAL].[dbo].[INT_FACT_VENTAS]
SET WARNING = 
    CASE 
        WHEN CONCAT(COD_PRODUCTO, COD_CATEGORIA, COD_CLIENTE, COD_PAIS, COD_VENDEDOR, COD_SUCURSAL, CONVERT(VARCHAR(10),FECHA,112)) 
             IN (
                SELECT CONCAT(COD_PRODUCTO, COD_CATEGORIA, COD_CLIENTE, COD_PAIS, COD_VENDEDOR, COD_SUCURSAL, CONVERT(VARCHAR(10),FECHA,112))
                FROM [DW_COMERCIAL].[dbo].[INT_FACT_VENTAS]
                GROUP BY COD_PRODUCTO, COD_CATEGORIA, COD_CLIENTE, COD_PAIS, COD_VENDEDOR, COD_SUCURSAL, CONVERT(VARCHAR(10),FECHA,112)
                HAVING COUNT(*) > 1
            ) 
        THEN 'WARNING'
        ELSE 'OK'
    END
END
GO

--sp_carga_int_dim_producto
CREATE PROCEDURE [dbo].[sp_carga_int_dim_producto]
AS
BEGIN
      --Borrado de datos que pudieran quedar en la tabla
      DELETE FROM [DW_COMERCIAL].[dbo].[INT_DIM_PRODUCTO] WHERE 0=0;
      --Insert los datos de la STG_DIM_PRODUCTO
      INSERT INTO [DW_COMERCIAL].[dbo].[INT_DIM_PRODUCTO] (
                                                          COD_PRODUCTO,
		                                                  DESC_PRODUCTO)
      SELECT COD_PRODUCTO,
             DESC_PRODUCTO
      FROM [DW_COMERCIAL].[dbo].[STG_DIM_PRODUCTO];
	  --Creacion tabla temporal de categor�as y productos con informaci�n proveniente de la tabla de ventas  
	  SELECT DISTINCT COD_CATEGORIA, COD_PRODUCTO
      INTO TEMP_CATEGORIA_PRODUCTO
      FROM [DW_COMERCIAL].[dbo].[INT_FACT_VENTAS];
	  --Asignar a cada producto una categor�a segun la tabla temporal
      UPDATE [DW_COMERCIAL].[dbo].[INT_DIM_PRODUCTO]
      SET COD_CATEGORIA = V.COD_CATEGORIA
      FROM [DW_COMERCIAL].[dbo].[INT_DIM_PRODUCTO] P
      INNER JOIN [DW_COMERCIAL].[dbo].[TEMP_CATEGORIA_PRODUCTO] V
      ON P.COD_PRODUCTO = V.COD_PRODUCTO;
      -- Se elimina la tabla temporal para que si se ejecuta nuevamente el sp se puede hacer sin problemas
      DROP TABLE [DW_COMERCIAL].[dbo].[TEMP_CATEGORIA_PRODUCTO];
	  --Verificar que no haya inconsistencias entre los datos de la tabla
	 UPDATE INT_DIM_PRODUCTO
     SET WARNING = CASE 
                    WHEN COD_PRODUCTO IN (
                            SELECT COD_PRODUCTO
                            FROM INT_DIM_PRODUCTO
                            GROUP BY COD_PRODUCTO
                            HAVING COUNT(DISTINCT DESC_PRODUCTO) > 1
                        ) 
                        THEN 'WARNING'
                    WHEN DESC_PRODUCTO IN (
                            SELECT DESC_PRODUCTO
                            FROM INT_DIM_PRODUCTO
                            GROUP BY DESC_PRODUCTO
                            HAVING COUNT(DISTINCT COD_PRODUCTO) > 1
                        ) 
                        THEN 'WARNING'
                    ELSE 'OK'
                END;
	 --Comparar contra la tabla dim para ver si ya figura o hay que hacerle una modificacion
	  UPDATE INT_DIM_PRODUCTO
      SET AGREGAR = 
                   CASE 
                   WHEN EXISTS (
                                SELECT 1 
                                FROM DIM_PRODUCTO 
                                 WHERE DIM_PRODUCTO.COD_PRODUCTO = INT_DIM_PRODUCTO.COD_PRODUCTO 
                                AND DIM_PRODUCTO.DESC_PRODUCTO = INT_DIM_PRODUCTO.DESC_PRODUCTO)
				   THEN 'NO'
				   WHEN EXISTS (
                                SELECT 1 
                                FROM DIM_PRODUCTO 
                                WHERE DIM_PRODUCTO.COD_PRODUCTO = INT_DIM_PRODUCTO.COD_PRODUCTO 
                                  AND (DIM_PRODUCTO.DESC_PRODUCTO <> INT_DIM_PRODUCTO.DESC_PRODUCTO 
                                       OR DIM_PRODUCTO.CATEGORIA_KEY <> CAST(SUBSTRING(INT_DIM_PRODUCTO.COD_CATEGORIA, 5, LEN(INT_DIM_PRODUCTO.COD_CATEGORIA))AS INT
                                    )))
                   THEN 'MODIFICAR'
                   ELSE 'SI' 
				   END;
END
GO

--sp_carga_int_dim_categor�a
CREATE PROCEDURE [dbo].[sp_carga_int_dim_categoria]
AS
BEGIN
    -- Eliminar datos antiguos de la tabla de dimensiones
    DELETE FROM  [DW_COMERCIAL].[dbo].[INT_DIM_CATEGORIA]
    
    -- Insertar nuevas filas en la tabla de dimensiones desde la tabla de origen
    INSERT INTO [DW_COMERCIAL].[dbo].[INT_DIM_CATEGORIA] (COD_CATEGORIA, DESC_CATEGORIA)
    SELECT COD_CATEGORIA, [Desc_Categoria]
    FROM [DW_COMERCIAL].[dbo].[STG_DIM_CATEGORIA]
    -- Verificacion de la existencia o no de los registros en la tabla dim_categor�a
    UPDATE INT_DIM_CATEGORIA
    SET AGREGAR = 
                 CASE 
                     WHEN EXISTS (
                                  SELECT 1 
                                  FROM DIM_CATEGORIA 
                                  WHERE DIM_CATEGORIA.COD_CATEGORIA = INT_DIM_CATEGORIA.COD_CATEGORIA 
                                  AND DIM_CATEGORIA.DESC_CATEGORIA = INT_DIM_CATEGORIA.DESC_CATEGORIA)
                     THEN 'NO'
					 WHEN EXISTS (
                                SELECT 1 
                                FROM DIM_CATEGORIA
                                WHERE DIM_CATEGORIA.COD_CATEGORIA = INT_DIM_CATEGORIA.COD_CATEGORIA 
                                  AND (DIM_CATEGORIA.DESC_CATEGORIA <> INT_DIM_CATEGORIA.DESC_CATEGORIA 
                                    )                                    )
                   THEN 'MODIFICAR'
                 ELSE 'SI' 
    END;
    --Verificar que no haya codigos o descripciones repetidas
    UPDATE INT_DIM_CATEGORIA
    SET WARNING = CASE 
                  WHEN COD_CATEGORIA IN (
                        SELECT COD_CATEGORIA
                        FROM INT_DIM_CATEGORIA
                        GROUP BY COD_CATEGORIA
                        HAVING COUNT(DISTINCT DESC_CATEGORIA) > 1
                    ) 
                    THEN 'WARNING'
                  WHEN DESC_CATEGORIA IN (
                        SELECT DESC_CATEGORIA
                        FROM INT_DIM_CATEGORIA
                        GROUP BY DESC_CATEGORIA
                        HAVING COUNT(DISTINCT COD_CATEGORIA) > 1
                    ) 
                    THEN 'WARNING'
                ELSE 'OK'
            END;
END
GO

--CREACION FUNCION APELLIDO
CREATE FUNCTION [dbo].[f_apellido] (@fullname VARCHAR(100))
RETURNS VARCHAR(100)
AS
BEGIN
DECLARE @apellido1 VARCHAR(50), @apellido2 VARCHAR(50)

SELECT @apellido1 = PARSENAME(REPLACE(@fullname, ' ', '.'), 2),
       @apellido2 = PARSENAME(REPLACE(@fullname, ' ', '.'), 3)
       
RETURN CONCAT(@apellido1, ' ', @apellido2)
END
GO

--sp_carga_int_dim_cliente
CREATE PROCEDURE [dbo].[sp_carga_int_dim_cliente]
AS
BEGIN
    -- Eliminar datos antiguos de la tabla de dimensiones
    DELETE FROM  [DW_COMERCIAL].[dbo].[INT_DIM_CLIENTE]
    
    -- Inserta los datos en INT_DIM_CLIENTE
    INSERT INTO [DW_COMERCIAL].[dbo].[INT_DIM_CLIENTE] (COD_CLIENTE, NOMBRE, APELLIDO)
    SELECT COD_Cliente, 
    SUBSTRING(desc_cliente, 1, CHARINDEX(' ', desc_cliente) - 1) AS nombre,
    SUBSTRING(desc_cliente, CHARINDEX(' ', desc_cliente) + 1, LEN(desc_cliente))
	FROM[DW_COMERCIAL].[dbo].[STG_DIM_CLIENTE];

    -- Verificar la existencia o no en la tabla DIM_CLIENTE
    UPDATE INT_DIM_CLIENTE
    SET AGREGAR = 
                 CASE 
                   WHEN EXISTS (
                                SELECT 1 
                                FROM DIM_CLIENTE 
                                WHERE DIM_CLIENTE.COD_CLIENTE = INT_DIM_CLIENTE.COD_CLIENTE 
                                )
                  THEN 'NO'
                ELSE 'SI' 
    END;

   -- Verificar que no haya c�digos repetidos o nombres y apellidos repetidos
   UPDATE INT_DIM_CLIENTE
   SET WARNING = CASE 
                 WHEN COD_CLIENTE IN (
                        SELECT COD_CLIENTE
                        FROM INT_DIM_CLIENTE
                        GROUP BY COD_CLIENTE
                       HAVING COUNT(DISTINCT NOMBRE + ' ' + APELLIDO) > 1
                    ) 
                    THEN 'WARNING'
        WHEN CONCAT(NOMBRE, ' ', APELLIDO) IN (
            SELECT CONCAT(NOMBRE, ' ',APELLIDO)
            FROM INT_DIM_CLIENTE
            GROUP BY CONCAT(NOMBRE, ' ', APELLIDO)
            HAVING COUNT(DISTINCT COD_CLIENTE) > 1
        ) 
        THEN 'WARNING'
        ELSE 'OK'
          END;
					      
END
GO

--sp_cargar_int_dim_pais
CREATE PROCEDURE [dbo].[sp_carga_int_dim_pais]
AS
BEGIN
 -- Eliminamos los registros existentes en la tabla INT_DIM_PAIS
    DELETE FROM [DW_COMERCIAL].[dbo].[INT_DIM_PAIS] WHERE 0=0
    
 -- Insertamos los registros de la tabla STG_DIM_PAIS en la tabla INT_DIM_PAIS
    INSERT INTO [DW_COMERCIAL].[dbo].[INT_DIM_PAIS] (COD_PAIS, DESC_PAIS)
    SELECT COD_PAIS, DESC_PAIS
    FROM [DW_COMERCIAL].[dbo].[STG_DIM_PAIS]
 -- Verificar la existencia o no en la tabla DIM_PAIS
    UPDATE INT_DIM_PAIS
    SET AGREGAR = 
                 CASE 
                  WHEN EXISTS (
                               SELECT 1 
                               FROM DIM_PAIS 
                               WHERE DIM_PAIS.COD_PAIS = INT_DIM_PAIS.COD_PAIS 
                               AND DIM_PAIS.DESC_PAIS = INT_DIM_PAIS.DESC_PAIS)
                     THEN 'NO'
                 ELSE 'SI' 
    END;

    -- Verificar que no haya c�digos repetidos o descripciones repetidas
      UPDATE INT_DIM_PAIS
      SET WARNING = CASE 
                      WHEN COD_PAIS IN (
                                        SELECT COD_PAIS
                                        FROM INT_DIM_PAIS
                                        GROUP BY COD_PAIS
                                        HAVING COUNT(DISTINCT DESC_PAIS) > 1
                                         ) 
                         THEN 'WARNING'
                      WHEN DESC_PAIS IN (
                                         SELECT DESC_PAIS
                                         FROM INT_DIM_PAIS
                                         GROUP BY DESC_PAIS
                                         HAVING COUNT(DISTINCT COD_PAIS) > 1
                                          ) 
                          THEN 'WARNING'
                      ELSE 'OK'
            END;   
END
GO

--sp_carga_int_dim_vendedor
CREATE PROCEDURE [dbo].[sp_carga_int_dim_vendedor]
AS
BEGIN
    DELETE FROM [DW_COMERCIAL].[dbo].[INT_DIM_VENDEDOR];

    INSERT INTO [DW_COMERCIAL].[dbo].[INT_DIM_VENDEDOR] (COD_VENDEDOR, NOMBRE, APELLIDO)
    SELECT 
        COD_VENDEDOR, 
        LEFT(DESC_VENDEDOR, CHARINDEX(' ', DESC_VENDEDOR) - 1) AS NOMBRE,
        SUBSTRING(DESC_VENDEDOR, CHARINDEX(' ', DESC_VENDEDOR) + 1, 500) AS APELLIDO
    FROM [DW_COMERCIAL].[dbo].[STG_DIM_VENDEDOR]
	--Creacion tabla temporal de VENDEDORES Y SUCURSALES con informaci�n proveniente de la tabla de ventas  
	  SELECT DISTINCT COD_VENDEDOR, COD_SUCURSAL
      INTO TEMP_VENDEDOR_SUCURSAL
      FROM [DW_COMERCIAL].[dbo].[INT_FACT_VENTAS];
	  --Asignar a cada producto una categor�a segun la tabla temporal
      UPDATE [DW_COMERCIAL].[dbo].[INT_DIM_VENDEDOR]
      SET COD_SUCURSAL = V.COD_SUCURSAL
      FROM [DW_COMERCIAL].[dbo].[INT_DIM_VENDEDOR] P
      INNER JOIN [DW_COMERCIAL].[dbo].[TEMP_VENDEDOR_SUCURSAL] V
      ON P.COD_VENDEDOR = V.COD_VENDEDOR;
      -- Se elimina la tabla temporal para que si se ejecuta nuevamente el sp se puede hacer sin problemas
      DROP TABLE [DW_COMERCIAL].[dbo].[TEMP_VENDEDOR_SUCURSAL];

    -- Verificar la existencia o no en la tabla DIM_VENDEDOR
    UPDATE INT_DIM_VENDEDOR
    SET AGREGAR =
            CASE
            WHEN EXISTS (SELECT 1
			             FROM DIM_VENDEDOR
			             WHERE DIM_VENDEDOR.COD_VENDEDOR = INT_DIM_VENDEDOR.COD_VENDEDOR
			             AND DIM_VENDEDOR.NOMBRE = INT_DIM_VENDEDOR.NOMBRE
			             AND DIM_VENDEDOR.APELLIDO = INT_DIM_VENDEDOR.APELLIDO)
            THEN 'NO'
		ELSE 'SI'
      END;

    -- Verificar que no haya c�digos repetidos o nombres y apellidos repetidos
    UPDATE INT_DIM_VENDEDOR
    SET WARNING = CASE
                     WHEN COD_VENDEDOR IN (
                                           SELECT COD_VENDEDOR
                                           FROM INT_DIM_VENDEDOR
                                           GROUP BY COD_VENDEDOR
                                           HAVING COUNT(DISTINCT NOMBRE + ' ' + APELLIDO) > 1
                                            )
                      THEN 'WARNING'
                     WHEN CONCAT(NOMBRE, ' ', APELLIDO) IN (
                                                            SELECT CONCAT(NOMBRE, ' ',APELLIDO)
                                                            FROM INT_DIM_VENDEDOR
                                                            GROUP BY CONCAT(NOMBRE, ' ', APELLIDO)
                                                            HAVING COUNT(DISTINCT COD_VENDEDOR) > 1
                                                             )
                     THEN 'WARNING'
                     WHEN COD_VENDEDOR IS NULL OR NOMBRE IS NULL OR APELLIDO IS NULL OR COD_SUCURSAL IS NULL
					 THEN 'WARNING'
				   ELSE 'OK'
                   END;
END
GO

--sp_carga_int_dim_sucursal
CREATE PROCEDURE [dbo].[sp_carga_int_dim_sucursal]
AS
BEGIN
    -- Eliminar registros existentes en la tabla INT_DIM_SUCURSAL
    DELETE FROM [DW_COMERCIAL].[dbo].[INT_DIM_SUCURSAL];

    -- Insertar registros en la tabla INT_DIM_SUCURSAL desde STG_DIM_SUCURSAL
    INSERT INTO [DW_COMERCIAL].[dbo].[INT_DIM_SUCURSAL] (COD_SUCURSAL, DESC_SUCURSAL)
    SELECT COD_SUCURSAL, DESC_SUCURSAL
    FROM [DW_COMERCIAL].[dbo].[STG_DIM_SUCURSAL];
	--Creacion tabla temporal de SUCURSALES Y PAISES con informaci�n proveniente de la tabla de ventas  
	  SELECT DISTINCT COD_PAIS, COD_SUCURSAL
      INTO TEMP_PAIS_SUCURSAL
      FROM [DW_COMERCIAL].[dbo].[INT_FACT_VENTAS];
	  --Asignar a cada producto una categor�a segun la tabla temporal
      UPDATE [DW_COMERCIAL].[dbo].[INT_DIM_SUCURSAL]
      SET COD_PAIS = V.COD_PAIS
      FROM [DW_COMERCIAL].[dbo].[INT_DIM_SUCURSAL] P
      INNER JOIN [DW_COMERCIAL].[dbo].[TEMP_PAIS_SUCURSAL] V
      ON P.COD_SUCURSAL = V.COD_SUCURSAL;
      -- Se elimina la tabla temporal para que si se ejecuta nuevamente el sp se puede hacer sin problemas
      DROP TABLE [DW_COMERCIAL].[dbo].[TEMP_PAIS_SUCURSAL];
	-- Verificar la existencia o no en la tabla DIM_SUCURSAL
    UPDATE INT_DIM_SUCURSAL
      SET AGREGAR = 
                    CASE 
                       WHEN EXISTS (
                                    SELECT 1 
                                    FROM DIM_SUCURSAL 
                                    WHERE DIM_SUCURSAL.COD_SUCURSAL = INT_DIM_SUCURSAL.COD_SUCURSAL 
                                    AND DIM_SUCURSAL.DESC_SUCURSAL = INT_DIM_SUCURSAL.DESC_SUCURSAL
                                    )
                         THEN 'NO'
						  WHEN EXISTS (
                                SELECT 1 
                                FROM DIM_SUCURSAL
                                WHERE DIM_SUCURSAL.COD_SUCURSAL = INT_DIM_SUCURSAL.COD_SUCURSAL 
                                  AND (DIM_SUCURSAL.DESC_SUCURSAL <> INT_DIM_SUCURSAL.DESC_SUCURSAL 
                                    )                                    )
                   THEN 'MODIFICAR'
					  ELSE 'SI' 
           END

-- Verificar que no haya c�digos repetidos o nombres de sucursal y PAISES REPETIDOS
    UPDATE INT_DIM_SUCURSAL
     SET WARNING = CASE 
                     WHEN COD_SUCURSAL IN (
                                           SELECT COD_SUCURSAL
                                           FROM INT_DIM_SUCURSAL
                                           GROUP BY COD_SUCURSAL
                                           HAVING COUNT(DISTINCT DESC_SUCURSAL) > 1
                                             ) 
                    THEN 'WARNING'
                     WHEN DESC_SUCURSAL IN (
                                              SELECT DESC_SUCURSAL
                                              FROM INT_DIM_SUCURSAL
                                              GROUP BY DESC_SUCURSAL
                                              HAVING COUNT(DISTINCT COD_SUCURSAL) > 1
                                               ) 
                    THEN 'WARNING'
					 WHEN DESC_SUCURSAL IN (
                                              SELECT DESC_SUCURSAL
                                              FROM INT_DIM_SUCURSAL
                                              GROUP BY DESC_SUCURSAL
                                              HAVING COUNT(DISTINCT COD_PAIS) > 1
                                               ) 
                    THEN 'WARNING'
					WHEN COD_SUCURSAL IS NULL OR DESC_SUCURSAL IS NULL OR COD_PAIS IS NULL
					THEN 'WARNING'
                   ELSE 'OK'
                END

END
GO

-- SP FINALES
--sp_carga_dim_producto
CREATE PROCEDURE [dbo].[sp_carga_dim_producto]
AS
BEGIN
  -- Agregar nuevos registros
  INSERT INTO DIM_PRODUCTO (PRODUCTO_KEY, 
                            COD_PRODUCTO, 
							DESC_PRODUCTO, 
							CATEGORIA_KEY, 
							FECHA_ALTA, 
							USUARIO_ALTA, 
							FECHA_UPDATE, 
							USUARIO_UPDATE)
  SELECT CAST(SUBSTRING(COD_PRODUCTO, 5, LEN(COD_PRODUCTO)) AS INT),
        COD_PRODUCTO,
        DESC_PRODUCTO,
	    CAST(SUBSTRING(COD_CATEGORIA, 5, LEN(COD_CATEGORIA)) AS INT),
        GETDATE(), 
		 SUSER_SNAME(), 
		 GETDATE(), 
		 SUSER_SNAME()
  FROM INT_DIM_PRODUCTO
  WHERE AGREGAR = 'SI' AND WARNING = 'OK' 
  -- Modificar registros existentes
  UPDATE DIM_PRODUCTO
  SET DESC_PRODUCTO = INT_DIM_PRODUCTO.DESC_PRODUCTO, 
      CATEGORIA_KEY = CAST(SUBSTRING(COD_CATEGORIA, 5, LEN(COD_CATEGORIA)) AS INT),
      FECHA_UPDATE = GETDATE(), 
	  USUARIO_UPDATE = SUSER_SNAME()
  FROM DIM_PRODUCTO
  INNER JOIN INT_DIM_PRODUCTO ON DIM_PRODUCTO.COD_PRODUCTO = INT_DIM_PRODUCTO.COD_PRODUCTO
  WHERE INT_DIM_PRODUCTO.AGREGAR = 'MODIFICAR' AND INT_DIM_PRODUCTO.WARNING = 'OK'
END
GO

--sp_carga_dim_categoria
CREATE PROCEDURE [dbo].[sp_carga_dim_categoria]
AS
BEGIN
  -- Agregar nuevos registros
  INSERT INTO DIM_CATEGORIA (
    CATEGORIA_KEY, 
    COD_CATEGORIA, 
    DESC_CATEGORIA, 
    FECHA_ALTA, 
    USUARIO_ALTA, 
    FECHA_UPDATE, 
    USUARIO_UPDATE
)
SELECT 
    CAST(SUBSTRING(COD_CATEGORIA, 5, LEN(COD_CATEGORIA)) AS INT), 
    COD_CATEGORIA, 
    DESC_CATEGORIA, 
    GETDATE(), 
    SUSER_SNAME(), 
    GETDATE(), 
    SUSER_SNAME()
FROM 
    INT_DIM_CATEGORIA
WHERE 
    AGREGAR = 'SI' AND WARNING = 'OK';

-- Update existing records
UPDATE 
    DIM_CATEGORIA
SET 
    DESC_CATEGORIA = INT_DIM_CATEGORIA.DESC_CATEGORIA, 
    FECHA_UPDATE = GETDATE(), 
    USUARIO_UPDATE = SUSER_SNAME()
FROM 
    DIM_CATEGORIA
    INNER JOIN INT_DIM_CATEGORIA ON DIM_CATEGORIA.COD_CATEGORIA = INT_DIM_CATEGORIA.COD_CATEGORIA
WHERE 
    INT_DIM_CATEGORIA.AGREGAR = 'MODIFICAR' AND INT_DIM_CATEGORIA.WARNING = 'OK'
END
GO

--sp_carga_dim_cliente
CREATE PROCEDURE [dbo].[sp_carga_dim_cliente]
AS
BEGIN
  -- Agregar nuevos registros
  INSERT INTO DIM_CLIENTE (CLIENTE_KEY,
                         COD_CLIENTE, 
                         NOMBRE, 
						 APELLIDO,
						 FECHA_ALTA, 
						 USUARIO_ALTA,
						 FECHA_UPDATE,
						 USUARIO_UPDATE)
SELECT CAST(SUBSTRING(COD_CLIENTE, 5, LEN(COD_CLIENTE)) AS INT),
       COD_CLIENTE, 
       NOMBRE, 
	   APELLIDO, 
	    GETDATE(), 
		 SUSER_SNAME(), 
		 GETDATE(), 
		 SUSER_SNAME()
FROM INT_DIM_CLIENTE
WHERE AGREGAR = 'SI' AND WARNING = 'OK';
END
GO

--sp_carga_dim_pais
CREATE PROCEDURE [dbo].[sp_carga_dim_pais]
AS
BEGIN
  -- Agregar nuevos registros
  INSERT INTO DIM_PAIS (COD_PAIS, 
                      DESC_PAIS, 
					  FECHA_ALTA, 
					  USUARIO_ALTA,
					  FECHA_UPDATE,
					  USUARIO_UPDATE)
SELECT COD_PAIS, 
       DESC_PAIS, 
	    GETDATE(), 
		 SUSER_SNAME(), 
		 GETDATE(), 
		 SUSER_SNAME()
FROM INT_DIM_PAIS
WHERE AGREGAR = 'SI' AND WARNING = 'OK' AND COD_PAIS NOT IN (SELECT COD_PAIS FROM DIM_PAIS);
--Esta �ltima condici�n se agrega para que si por equivocacion se ejecuta dos veces este sp sin modificar la tabla int, no se generen duplicados
--Esto es necesario porque el pais_key no guarda relacion con el cod_pa�s
END
GO

--sp_carga_dim_sucursal
CREATE PROCEDURE [dbo].[sp_carga_dim_sucursal]
AS
BEGIN
  -- Agregar nuevos registros
INSERT INTO DIM_SUCURSAL (SUCURSAL_KEY,
                          COD_SUCURSAL, 
						  DESC_SUCURSAL, 
						  PAIS_KEY,
						  FECHA_ALTA, 
						  USUARIO_ALTA,
						  FECHA_UPDATE,
						  USUARIO_UPDATE)
SELECT CAST(SUBSTRING(COD_SUCURSAL, 5, LEN(COD_SUCURSAL)) AS INT),
       COD_SUCURSAL, 
       DESC_SUCURSAL, 
       DIM_PAIS.PAIS_KEY,
	   GETDATE(), 
	   SUSER_SNAME(), 
	   GETDATE(), 
	   SUSER_SNAME()
FROM INT_DIM_SUCURSAL
INNER JOIN DIM_PAIS ON INT_DIM_SUCURSAL.COD_PAIS = DIM_PAIS.COD_PAIS
WHERE AGREGAR = 'SI' AND WARNING = 'OK';
--Actualizar cambios DESC_SUCURSAL
UPDATE DIM_SUCURSAL
SET DESC_SUCURSAL = INT_DIM_SUCURSAL.DESC_SUCURSAL,
FECHA_UPDATE = GETDATE(),
USUARIO_UPDATE = SUSER_SNAME()
FROM DIM_SUCURSAL
INNER JOIN INT_DIM_SUCURSAL ON DIM_SUCURSAL.COD_SUCURSAL = INT_DIM_SUCURSAL.COD_SUCURSAL
WHERE INT_DIM_SUCURSAL.AGREGAR = 'MODIFICAR' AND INT_DIM_SUCURSAL.WARNING = 'OK' 
END
GO

--sp_carga_dim_venndedor
CREATE PROCEDURE [dbo].[sp_carga_dim_vendedor]
AS
BEGIN
  -- Agregar nuevos registros
INSERT INTO DIM_VENDEDOR (VENDEDOR_KEY,
                          COD_VENDEDOR, 
                          NOMBRE, 
						  APELLIDO, 
						  SUCURSAL_KEY,
						  FECHA_ALTA, 
						  USUARIO_ALTA,
						  FECHA_UPDATE,
						  USUARIO_UPDATE)
SELECT CAST(SUBSTRING(COD_VENDEDOR, 5, LEN(COD_VENDEDOR)) AS INT),
       COD_VENDEDOR, 
       NOMBRE, 
	   APELLIDO, 
	   CAST(SUBSTRING(COD_SUCURSAL, 5, LEN(COD_SUCURSAL)) AS INT),
	    GETDATE(), 
		 SUSER_SNAME(), 
		 GETDATE(), 
		 SUSER_SNAME()
FROM INT_DIM_VENDEDOR
WHERE AGREGAR = 'SI' AND WARNING = 'OK';
END
GO

--sp_carga_fact_ventas
CREATE PROCEDURE sp_carga_fact_ventas
AS
BEGIN
     DELETE FROM FACT_VENTAS
     WHERE TIEMPO_KEY >= (SELECT MIN(TIEMPO_KEY) FROM INT_FACT_VENTAS)
    -- Insertar los valores en la tabla FACT_VENTAS
    INSERT INTO [dbo].[FACT_VENTAS]
    ([PRODUCTO_KEY]
    ,[CATEGORIA_KEY]
    ,[CLIENTE_KEY]
    ,[PAIS_KEY]
    ,[VENDEDOR_KEY]
    ,[SUCURSAL_KEY]
    ,[TIEMPO_KEY]
    ,[CANTIDAD_VENDIDA]
    ,[MONTO_VENDIDO]
    ,[PRECIO]
    ,[COMISION_COMERCIAL]
    ,[FECHA_ALTA]
    ,[USUARIO_ALTA])
    SELECT [PRODUCTO_KEY]
    ,[CATEGORIA_KEY]
    ,[CLIENTE_KEY]
    ,[PAIS_KEY]
    ,[VENDEDOR_KEY]
    ,[SUCURSAL_KEY]
    ,[TIEMPO_KEY]
    ,[CANTIDAD_VENDIDA]
    ,[MONTO_VENDIDO]
    ,[PRECIO]
    ,[COMISION_COMERCIAL]
    ,GETDATE()
    ,SUSER_SNAME()
FROM INT_FACT_VENTAS
END
GO
