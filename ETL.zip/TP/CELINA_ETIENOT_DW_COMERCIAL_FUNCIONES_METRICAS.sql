-- FUNCION PARA MONTO TOTAL DE VENTAS
CREATE FUNCTION dbo.MontoTotalVentas()
RETURNS MONEY
AS
BEGIN
  DECLARE @montoTotal MONEY;
  SET @montoTotal = (SELECT SUM(MONTO_VENDIDO) FROM FACT_VENTAS);
  RETURN @montoTotal;
END;

CREATE FUNCTION dbo.CantidadVendida()
RETURNS INT
AS
BEGIN
  DECLARE @cantidadVendida INT;
  SET @cantidadVendida = (SELECT SUM(CANTIDAD_VENDIDA) FROM FACT_VENTAS);
  RETURN @cantidadVendida;
END;

CREATE FUNCTION dbo.MontoPromedioVentas()
RETURNS MONEY
AS
BEGIN
  DECLARE @montoPromedio MONEY;
  SET @montoPromedio = (SELECT AVG(MONTO_VENDIDO) FROM FACT_VENTAS);
  RETURN @montoPromedio;
END;

CREATE FUNCTION dbo.ImporteComisionComercial()
RETURNS MONEY
AS
BEGIN
  DECLARE @importeComision MONEY;
  SET @importeComision = (SELECT SUM(COMISION_COMERCIAL) FROM FACT_VENTAS);
  RETURN @importeComision;
END;

CREATE FUNCTION dbo.CantidadClientes()
RETURNS INT
AS
BEGIN
  DECLARE @cantidadClientes INT;
  SET @cantidadClientes = (SELECT COUNT(DISTINCT CLIENTE_KEY) FROM FACT_VENTAS);
  RETURN @cantidadClientes;
END;

